<?php 
   
   if ($_SERVER["REQUEST_METHOD"] == "POST") {

       $name = $_POST['name'];
       $email = $_POST['email'];
       $message = $_POST['message'];
    
    
       
    if(empty($name) || empty($email) || empty($message))
    {
                            
        echo "All the fileds are required";
                         }
    else
    {
        $conn = mysqli_connect('localhost', 'root', '', 'workforce');

    // Check connection

    if (!$conn) {
        
      die("Connection failed: " . mysqli_connect_error());
    }

   $sql = "INSERT INTO contact_us (name,email,message) VALUES ('$name','$email','$message')";
   if (mysqli_query($conn, $sql)) 
   {
      echo "Your query has been successfully received. We will contact you soon! <br> Thank you for reaching us.";
     exit();
   }
   
        mysqli_close($conn);
    
    }
       
  }

/*

$toemail = 'patelvishu1996@gmail.com';
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
if(mail($toemail, 'Subject', $message, 'From: ' . $email)) {
	echo 'Your email was sent successfully.';
} else {
	echo 'There was a problem sending your email.';
}*/
?>