<?php
session_start();
if(!empty($_SESSION['username'])){
    $displayName= $_SESSION['username'];
}
else{
    $displayName= 'Welcome';
}
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>

<!-- Basic Page Needs ================================================== 
================================================== -->

<meta charset="utf-8">
<title>Contact us</title>
<meta name="description" content="Place to put your description text">
<meta name="author" content="">
<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

<!-- Mobile Specific Metas ================================================== 
================================================== -->

<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">

<!-- CSS ==================================================
================================================== -->

<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" href="css/screen.css">
<link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />

<!-- Favicons ==================================================
================================================== -->

<link rel="shortcut icon" href="images/favicon.png">
<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">

<!-- Google Fonts ==================================================
================================================== -->
<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
</head>
<body>

<!--Content Part ==================================================
================================================== -->
<div id="header">
  <div class="container"> 
    <!-- Header | Logo, Menu
		================================================== -->
    <div class="logo"><a href="index.php"><img src="images/work.png" alt="" height="90px" width="150px"/></a></div>
    <div class="mainmenu">
      <div id="mainmenu">
         <ul class="sf-menu">
          <li><a href="index.php" id="visited">Home</a></li>
          <li><a href="services.php">Services</a></li>
          <li><a href="features.php">Features</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li><a href="signup.php">Become a Professional</a></li>
          <li><a href="login.php">Login / Signup</a></li> 
          <li><a href="logout.php">Hello <?php echo $displayName; ?></a></li>     
        </ul>
      </div>
      <!-- mainmenu ends here --> 
      
      <!-- Responsive Menu -->
      <form id="responsive-menu" action="#" method="post">
         <select>
          <option value="">Navigation</option>
          <option value="index.php">Home</option>
          <option value="services.php">Services</option>
          <option value="features.php">Features</option>
          <option value="contact.php">Contact</option>
          <option value="signup.php">Become a Professional</option>
          <option value="login.php">Login / Signup</option>
        </select>
      </form>
    </div>
    <!-- mainmenu ends here --> 
  </div>
  <!-- container ends here --> 
</div>
<!-- header ends here --> 
<!--Breadcrumbs ==================================================
================================================== -->
<div class="breadcrumbs">
  <div class="container">
    <header>
      <h3>Contact Page</h3>
      <p>- Let us know,<span class="pink"> how did we do today?</span></p>
    </header>
  </div>
  <!-- container ends here -->
  <hr class="separator1">
</div>
<!-- breadcrumbs ends here --> 
<!-- Contact Content Part - GoogleMap ==================================================
================================================== -->
<section class="map"> 
  <!-- google map -->
  <div class="map-holder">
    <div class="map-container">
      <iframe class="map" src="https://www.google.ca/search?q=kitchener&tbm=isch&source=iu&ictx=1&fir=BPAZ4gqskQuHtM%253A%252CVRCwMmQwo5gjiM%252C%252Fm%252F0mbf4&vet=1&usg=AI4_-kRBmconyuNcNuf5ZLHLnrMRUvQS4A&sa=X&ved=2ahUKEwiFx_rU9drlAhWunuAKHUOlCpEQ_B0wHXoECAkQAw#imgrc=BPAZ4gqskQuHtM" Content-Security-Policy: frame-ancestors = 'self'></iframe>
      <!-- end google map --> 
    </div>
    <!--map-container ends here--> 
  </div>
  <!--map-holder ends here--> 
</section>
    
    
    
<div class="container">
  <div class="blankSeparator"></div>
  <div class="container">
    <h3>Our Team</h3>
    <div class="team">
      <div class="one_third"> <img class="shadow" src="images/developers/vish1.jpg" alt=""/>
        <section class="teaminfo">
          <h4>Vishvesh Patel</h4>
          <ul>
            <li>
              <p><a href="#"><strong>Founder</strong></a><br />
                Website: <a href="#">www.workforcealliance.com</a><br />
                Email: <a href="contact.php">info@workforcealliance.com</a></p>
            </li>
          </ul>
        </section>
      </div>
      <!-- end one-third column ends here -->
      <div class="one_third"> <img class="shadow" src="images/portfolio/b.jpg" alt=""/>
        <section class="teaminfo">
          <h4>Prashant Rathod</h4>
          <ul>
            <li>
              <p><a href="#"><strong>Co-Founder</strong></a><br />
                Website: <a href="#">www.workforcfe.com</a><br />
                Email: <a href="contact.php">info@workforce.com</a></p>
            </li>
          </ul>
        </section>
      </div>
      <!-- end one-third column ends here -->
      <div class="one_third lastcolumn"> <img class="shadow" src="images/portfolio/c.jpg" alt=""/>
        <section class="teaminfo">
          <h4>Raspreet Kaur</h4>
          <ul>
            <li>
              <p><a href="#"><strong>Co-Founder</strong></a><br />
                Website: <a href="#">www.workforcealliance.com</a><br />
                Email: <a href="contact.php">info@workforcealliance.com</a></p>
            </li>
          </ul>
        </section>
      </div>
      <!-- end one-third column ends here --> 
    </div>
  </div>
</div>
    
    

<!-- Contact Content Part - Contact Form ==================================================
================================================== -->
<div class="container contact"> 
  <!-- Contact Sidebar ==================================================
================================================== -->
  <div class="one_third">
    <h3>Our Info</h3>
    <section class="first shadow">
      <ul>
        <li>123456 Toronto Street, Kitchener</li>
        <li>Phone: (1800) 987-12341</li>
        <li>Fax: (1800) 987-12341</li>
        <li>Website: <a href="#" title="">http://workforcealliance.com</a></li>
        <li>Email: <a href="#" title="">info@workforcealliance.com</a></li>
      </ul>
    </section>
  </div>
  <!-- one_third ends here -->
  <div class="two_third lastcolumn contact1">
    <div id="contactForm">
      <h3>Contact us</h3>
      <div class="sepContainer"></div>
      <form action="process.php" method="post" id="contact_form">
        <div class="name">
          <label for="name">Your Name:</label>
          <p> Please enter your full name</p>
          <input id="name" name=name type=text placeholder="e.g. Mr. Jeff Patel" required />
        </div>
        <div class="email">
          <label for="email">Your Email:</label>
          <p> Please enter your email address</p>
          <input id=email name=email type=email placeholder="example@domain.com" required />
        </div>
        <div class="message">
          <label for="message">Your Message:</label>
          <p> Please enter your question</p>
          <textarea id=message name=message rows=6 cols=10 required></textarea>
        </div>
        <div id="loader">
          <input type="submit" value="Submit" />
        </div>
      </form>
    </div>
    <!-- end contactForm --> 
  </div>
</div>
<div class="blankSeparator"></div>

<!-- Socialize ==================================================
================================================== -->
<hr class="separator2">
<div class="socialsblock">
  <div class="container socialize">
    <h3>Socialize with us!</h3>
    <section class="socials">
      <ul class="socials">
        <li><a href="#"><img src="images/socials/twitter.png" alt="" /></a></li>
        <li><a href="#"><img src="images/socials/facebook.png" alt="" /></a></li>
        <li><a href="#"><img src="images/socials/dribbble.png" alt="" /></a></li>
        <li><a href="#"><img src="images/socials/google+.png" alt="" /></a></li>
        <li><a href="#"><img src="images/socials/linkedin.png" alt="" /></a></li>
        <li><a href="#"><img src="images/socials/youtube.png" alt="" /></a></li>
      </ul>
    </section>
  </div>
  <!-- container ends here --> 
</div>
<!-- socialsblock ends here --> 
<!-- Footer ==================================================
================================================== -->
<div class="footer">
  <div class="container">
    <div class="one_fourth">
      <h3>Contact Informations</h3>
      <p><span class="orange"><strong>Address:</strong></span> <br>
        425 Wilson Avenue, Kitchener, ON, Canada, N2C 2R8</p>
      <p><span class="orange"><strong>Phone:</strong></span> <br>
        +1(226)9724868<br>
      </p>
      <p><span class="orange"><strong>Email:</strong></span> <br>
        info@workforcealliance.com<br>
      </p>
    </div>
    <!-- four columns ends here -->
    <div class="one_fourth">
      <h3>Our Services</h3>
      <ul>
        <li><a href="#" title="">Electrnoic Repair</a></li>
        <li><a href="#" class="">Plumbing</a></li>
        <li><a href="#" class="">Hair Artists</a></li>
        <li><a href="#" class="">Photography</a></li>
        <li><a href="#" class="">Decoration</a></li>
      </ul>
    </div>
    <!-- four columns ends here -->
    <div class="one_fourth">
      <h3>Archive</h3>
      <ul>
        <li><a href="#" class=""> August 2019</a></li>
        <li><a href="#" class="">July 2019</a></li>
        <li><a href="#" class="">Juny 2019</a></li>
        <li><a href="#" class=""> May 2019</a></li>
        <li><a href="#" class="">April 2019</a></li>
      </ul>
    </div>
    <!-- four columns ends here -->
    <div class="one_fourth lastcolumn">
      <h3>About</h3>
        <p>Workforce Alliance is a company that helps you to find what you need!</p>
    </div>
    <!-- four columns ends here --> 
  </div>
  <!-- container ends here --> 
</div>
<!-- footer ends here --> 
<!-- Copyright ==================================================
================================================== -->
<div id="copyright">
  <div class="container">
    <p class="copyright">&copy; Copyright 2019. &quot;WorkForce Alliance&quot; All rights reserved.</p>
  </div>
  <!-- container ends here --> 
</div>
<!-- copyright ends here --> 
<!-- End Document
================================================== --> 
<!-- Scripts ==================================================
================================================== --> 
<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script> 
<!-- Main js files --> 
<script src="js/screen.js" type="text/javascript"></script> 
<!-- Tabs --> 
<script src="js/tabs.js" type="text/javascript"></script> 
<!-- Include prettyPhoto --> 
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script> 
<!-- Include Superfish --> 
<script src="js/superfish.js" type="text/javascript"></script> 
<script src="js/hoverIntent.js" type="text/javascript"></script> 
<!-- Flexslider --> 
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script> 
<!-- Modernizr --> 
<script type="text/javascript" src="js/modernizr.custom.29473.js"></script>
</body>
</html>