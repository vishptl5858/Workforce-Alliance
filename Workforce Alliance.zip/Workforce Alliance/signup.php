<?php
   
   if ($_SERVER["REQUEST_METHOD"] == "POST") {

       
    $folder_path = 'uploads/';

    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $email =  $_POST['email'];
    $cemail = $_POST['cemail'];
    $password =  $_POST['password'];
    $cpassword =  $_POST['cpassword'];
    $phone =  $_POST['phone'];
    $street =  $_POST['street'];
    $city =  $_POST['city'];
    $country =  $_POST['country'];
    $gender= $_POST['gender'];
    $expertise= $_POST['expertise'];
    $date=  $_POST['adate'];
    $filename = basename($_FILES['resumefile']['name']);
    $newname = $folder_path. $filename;
    
       
    if(empty($email) || empty($password))
    {
                            
        echo "Email and password are required";
                         }
    else
    {
        $conn = mysqli_connect('localhost', 'root', '', 'workforce');

    // Check connection

    if (!$conn) {
        
      die("Connection failed: " . mysqli_connect_error());
    }

    if (move_uploaded_file($_FILES['resumefile']['tmp_name'], $newname)) {
        
   $sql = "INSERT INTO workerprofile (firstname,lastname,email,confirm_email,password,confirm_password,phone_number,street,city,country,gender,expertise,availability_date,pro_image) VALUES ('$fname','$lname','$email','$cemail','$password','$cpassword','$phone','$street','$city','$country','$gender','$expertise','$date','$filename')";
   if (mysqli_query($conn, $sql)) 
   {
      echo "New record created successfully";
      /* header("Location:confirmation.php");  Redirect browser */
     exit();
   } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
   }
   
        mysqli_close($conn);
    }
    }
       
  }


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="vendor/nouislider/nouislider.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/signup.css">
</head>

<body>

    <div class="main">
        <p class="back"><a href="index.php">Click here</a> to go back to home page</p>
        <div class="container">
            <div class="signup-content">
                <div class="signup-img">
                    <img src="images/form-img.jpg" alt="">
                    <div class="signup-img-content">
                        <h2>Register now </h2>
                        <p>Expand your expertise !</p>
                    </div>
                </div>
                <div class="signup-form">
                    <form method="POST" action="signup.php" enctype="multipart/form-data" class="register-form" id="register-form">
                        <div class="form-row">
                            <div class="form-group">
                                <div class="form-input">
                                    <label for="first_name" class="required">First name</label>
                                    <input type="text" name="firstname" id="firstname" />
                                </div>
                                <div class="form-input">
                                    <label for="email" class="required">Email</label>
                                    <input type="email" name="email" id="email" />
                                </div>

                                <div class="form-input">
                                    <label for="password" class="required">Password</label>
                                    <input type="password" name="password" id="password" />
                                </div>

                                <div class="form-input">
                                    <label for="phone_number" class="required">Phone number</label>
                                    <input type="number" name="phone" id="phone" />
                                </div>
                                <div class="form-input">
                                    <label for="street" class="required">Street</label>
                                    <input type="text" name="street" id="street" />
                                </div>
                                <div class="form-radio">
                                    <div class="label-flex">
                                        <label for="gender">Gender</label>
                                    </div>
                                    <div class="form-radio-group">
                                        <div class="form-radio-item">
                                            <input type="radio" value="male" name="gender" id="male" checked>
                                            <label for="male">Male</label>
                                            <span class="check"></span>
                                        </div>
                                        <div class="form-radio-item">
                                            <input type="radio" value="female" name="gender" id="female">
                                            <label for="female">Female</label>
                                            <span class="check"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-input">
                                    <label for="resume" class="required">Upload Your profile picture</label>
                                    <input type="file" name="resumefile">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-select">
                                    <div class="form-input">
                                        <label for="last_name" class="required">Last name</label>
                                        <input type="text" name="lastname" id="lastname" />
                                    </div>
                                    <div class="form-input">
                                        <label for="cemail" class="required">Confirm Email</label>
                                        <input type="email" name="cemail" id="cemail" />
                                    </div>
                                    <div class="form-input">
                                        <label for="cpassword" class="required">Confirm Password</label>
                                        <input type="password" name="cpassword" id="cpassword" />
                                    </div>
                                    <div class="form-input">
                                        <label for="city" class="required">City</label>
                                        <input type="city" name="city" id="city" />
                                    </div>
                                    <div class="label-flex">
                                        <label for="country">Country</label>
                                        <a href="#" class="form-link">Location detail</a>
                                    </div>
                                    <div class="select-list">
                                        <select name="country">
                                            <option value="canada">Canada</option>
                                            <option value="usa">United states</option>
                                            <option value="india">India</option>
                                        </select>
                                    </div>
                                    <div class="label-flex">
                                        <label for="expertise">Select your expertise</label>
                                    </div>
                                    <div class="select-list">
                                        <select name="expertise">
                                            <option value="plumber">Plumber</option>
                                            <option value="men_hair_stylish">Men's Hair stylish</option>
                                            <option value="photographer">Photography</option>
                                        </select>
                                    </div>

                                    <div class="form-input">
                                        <label for="date" class="required">Availability Date</label>
                                        <input type="date" name="adate" id="adate" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-submit">
                            <input type="submit" value="Submit" class="submit" id="submit" name="submit" />
                            <input type="button" value="Reset" class="submit" id="reset" name="reset" />
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/nouislider/nouislider.min.js"></script>
    <script src="vendor/wnumb/wNumb.js"></script>
    <script src="vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="vendor/jquery-validation/dist/additional-methods.min.js"></script>
    <script src="js/signup.js"></script>
</body>

</html>
