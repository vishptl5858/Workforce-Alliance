<?php
session_start();
if(!empty($_SESSION['username'])){
    $displayName= $_SESSION['username'];
}
else{
    $displayName= 'Welcome';
}
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>

    <!-- Basic Page Needs ================================================== 
================================================== -->

    <meta charset="utf-8">
    <title>Our Features</title>
    <meta name="description" content="Place to put your description text">
    <meta name="author" content="">
    <!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

    <!-- Mobile Specific Metas ================================================== 
================================================== -->

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">

    <!-- CSS ==================================================
================================================== -->

    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/skeleton.css">
    <link rel="stylesheet" href="css/screen.css">
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />

    <!-- Favicons ==================================================
================================================== -->

    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">

    <!-- Google Fonts ==================================================
================================================== -->
    <link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
</head>

<body>

    <!--Content Part ==================================================
================================================== -->
    <div id="header">
        <div class="container">
            <!-- Header | Logo, Menu
		================================================== -->
            <div class="logo"><a href="index.php"><img src="images/work.png" alt="" height="90px" width="150px" /></a></div>
            <div class="mainmenu">
                <div id="mainmenu">
                    <ul class="sf-menu">
                        <li><a href="index.php" id="visited">Home</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="signup.php">Become a Professional</a></li>
                        <li><a href="login.php">Login / Signup</a></li>
                        <li><a href="logout.php">Hello <?php echo $displayName; ?></a></li>
                    </ul>
                </div>
                <!-- mainmenu ends here -->

                <!-- Responsive Menu -->
                <form id="responsive-menu" action="#" method="post">
                    <select>
                        <option value="">Navigation</option>
                        <option value="index.php">Home</option>
                        <option value="services.php">Services</option>
                        <option value="features.php">Features</option>
                        <option value="contact.php">Contact</option>
                        <option value="signup.php">Become a Professional</option>
                        <option value="login.php">Login / Signup</option>
                    </select>
                </form>
            </div>
            <!-- mainmenu ends here -->
        </div>
        <!-- container ends here -->
    </div>
    <!-- header ends here -->
    <!--Breadcrumbs ==================================================
================================================== -->
    <div class="breadcrumbs">
        <div class="container">
            <header>
                <h3>Features Page</h3>
                <p>- WorkForce Alliance <span class="pink">Quality is not a goal to be achieved, It is a standard that needs to sustained</span><a href="" rel="nofollow"><strong>All Services At One Place</strong></a> -</p>
            </header>
        </div>
        <!-- container ends here -->
        <hr class="separator1">
    </div>
    <!-- breadcrumbs ends here -->
    <!-- Features ==================================================
================================================== -->
    <div id="resume">
        <div class="container resume">
            <h3>Workforce Services</h3>
            <p></p>
            <div class="one_third">
                <h4>Services</h4>
            </div>
            <div class="two_third lastcolumn">
                <p><strong>2019-2020</strong> </p>
                <p><strong>2019-2020</strong> </p>
            </div>
            <div class="one_third">
                <h4>Staff Skills</h4>
            </div>
            <div class="two_third lastcolumn">
                <p><strong>2019-2020</strong></p>
                <p><strong>2019-2020</strong></p>
            </div>
            <div class="one_third">
                <h4>Awards</h4>
            </div>
            <div class="two_third lastcolumn">
                <div class="one_fourth">
                    <p><img src="images/portfolio/a.jpg" alt="" /></p>
                    <p>2019 Best Quality Award</p>
                </div>
                <div class="one_fourth">
                    <p><img src="images/portfolio/c.jpg" alt="" /></p>
                    <p>2019 Service Award</p>
                </div>
                <div class="one_fourth">
                    <p><img src="images/portfolio/b.jpg" alt="" /></p>
                    <p>2018 Project Award</p>
                </div>
                <div class="one_fourth lastcolumn">
                    <p><img src="images/portfolio/a.jpg" alt="" /></p>
                    <p>2018 website of the Year</p>
                </div>
            </div>
            <div class="one_third">
                <h4>References</h4>
            </div>
            <div class="two_third lastcolumn">
                <div class="one_half">
                    <p><strong>Vishvesh Patel</strong><br />
                        Trustee at WorkForce in 2018<br />
                        200.000.0000</p>
                </div>
                <!--//grid_3-->
                <div class="one_half lastcolumn">
                    <p><strong>Shrey Patel</strong><br />
                        Managing Director at WorkForce in 2019<br />
                        300.000.0000</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Features FAQ ==================================================
================================================== -->
    <div class="container">
        <hr class="separator">
        <h3>Accordions</h3>
        <div class="accordion-trigger">
            <h3>What did you do?</h3>
        </div>
        <div class="accordion-container">
            <div class="one_third"> <img class="shadow" src="images/portfolio/c.jpg" alt="" /> </div>
            <!--end one_third-->
            <div class="one_third"> <img class="shadow" src="images/portfolio/a.jpg" alt="" /> </div>
            <!--end one_third-->
            <div class="one_third lastcolumn"> <img class="shadow" src="images/portfolio/b.jpg" alt="" /> </div>
            <!--end one_third-->
            <p></p>
            <hr class="separator1">
        </div>
        <div class="accordion-trigger">
            <h3>Morning?</h3>
        </div>
        <div class="accordion-container">
            <div class="one_half">
                <div class="video-holder">
                    <div class="video-container">
                        <iframe title="YouTube video player" class="youtube-player" src="http://www.youtube.com/embed/W7JXcoTty3Q"></iframe>
                    </div>
                    <!--video-container ends here-->
                </div>
                <!--video-holder ends here-->
            </div>
            <!--end one_half-->
            <div class="one_half lastcolumn">
                <div class="video-holder">
                    <div class="video-container">
                        <iframe title="YouTube video player" class="youtube-player" src="http://www.youtube.com/embed/W7JXcoTty3Q"></iframe>
                    </div>
                    <!--video-container ends here-->
                </div>
                <!--video-holder ends here-->
            </div>
            <!--end one_half-->
            <p> </p>
            <hr class="separator1">
        </div>
        <div class="accordion-trigger">
            <h3>would you be?</h3>
        </div>
        <div class="accordion-container">
            <p> </p>
            <hr class="separator1">
        </div>
        <div class="accordion-trigger">
            <h3>Your world?</h3>
        </div>
        <div class="accordion-container">
            <p> </p>
            <hr class="separator1">
        </div>
        <div class="accordion-trigger">
            <h3>Your favorite color?</h3>
        </div>
        <div class="accordion-container">
            <p> </p>
            <hr class="separator1">
        </div>
        <div class="accordion-trigger">
            <h3>The 5 things you can't live without?</h3>
        </div>
        <div class="accordion-container">
            <p></p>
            <hr class="separator1">
            <!-- ENDS Accordions -->
        </div>
        <hr class="separator">
        <h3>Tabs</h3>
        <ul class="tabs">
            <li><a class="active" href="#trends">Trends</a></li>
            <li><a class="" href="#fashion">Fashion</a></li>
            <li><a class="" href="#shows">Shows</a></li>
        </ul>
        <ul class="tabs-content">
            <li class="active" id="trends">
                <p</p> </li> <li id="fashion">
                    <p></p>
            </li>
            <li id="shows">
                <p></p>
            </li>
        </ul>
    </div>
    <!-- container ends here -->
    <div class="blankSeparator"></div>

    <!-- Socialize ==================================================
================================================== -->
    <hr class="separator2">
    <div class="socialsblock">
        <div class="container socialize">
            <h3>Socialize with us!</h3>
            <section class="socials">
                <ul class="socials">
                    <li><a href="#"><img src="images/socials/twitter.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/facebook.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/dribbble.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/google+.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/linkedin.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/youtube.png" alt="" /></a></li>
                </ul>
            </section>
        </div>
        <!-- container ends here -->
    </div>
    <!-- socialsblock ends here -->
    <!-- Footer ==================================================
================================================== -->
    <div class="footer">
        <div class="container">
            <div class="one_fourth">
                <h3>Contact Informations</h3>
                <p><span class="orange"><strong>Address:</strong></span> <br>
                    425 Wilson Avenue, Kitchener, ON, Canada, N2C 2R8</p>
                <p><span class="orange"><strong>Phone:</strong></span> <br>
                    +1(226)9724868<br>
                </p>
                <p><span class="orange"><strong>Email:</strong></span> <br>
                    info@workforcealliance.com<br>
                </p>
            </div>
            <!-- four columns ends here -->
            <div class="one_fourth">
                <h3>Our Services</h3>
                <ul>
                    <li><a href="#" title="">Electrnoic Repair</a></li>
                    <li><a href="#" class="">Plumbing</a></li>
                    <li><a href="#" class="">Hair Artists</a></li>
                    <li><a href="#" class="">Photography</a></li>
                    <li><a href="#" class="">Decoration</a></li>
                </ul>
            </div>
            <!-- four columns ends here -->
            <div class="one_fourth">
                <h3>Archive</h3>
                <ul>
                    <li><a href="#" class=""> August 2019</a></li>
                    <li><a href="#" class="">July 2019</a></li>
                    <li><a href="#" class="">Juny 2019</a></li>
                    <li><a href="#" class=""> May 2019</a></li>
                    <li><a href="#" class="">April 2019</a></li>
                </ul>
            </div>
            <!-- four columns ends here -->
            <div class="one_fourth lastcolumn">
                <h3>About</h3>
                <p>Workforce Alliance is a company that helps you to find what you need!</p>
            </div>
            <!-- four columns ends here -->
        </div>
        <!-- container ends here -->
    </div>
    <!-- footer ends here -->
    <!-- Copyright ==================================================
================================================== -->
    <div id="copyright">
        <div class="container">
            <p class="copyright">&copy; Copyright 2019. &quot;WorkForce Alliance&quot; All rights reserved.</p>
        </div>
        <!-- container ends here -->
    </div>
    <!-- copyright ends here -->
    <!-- End Document
================================================== -->
    <!-- Scripts ==================================================
================================================== -->
    <script src="js/jquery-1.8.0.min.js" type="text/javascript"></script>
    <!-- Main js files -->
    <script src="js/screen.js" type="text/javascript"></script>
    <!-- Tabs -->
    <script src="js/tabs.js" type="text/javascript"></script>
    <!-- Include prettyPhoto -->
    <script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
    <!-- Include Superfish -->
    <script src="js/superfish.js" type="text/javascript"></script>
    <script src="js/hoverIntent.js" type="text/javascript"></script>
    <!-- Flexslider -->
    <script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
    <!-- Modernizr -->
    <script type="text/javascript" src="js/modernizr.custom.29473.js"></script>
</body>

</html>
