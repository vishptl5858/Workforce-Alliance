<?php
session_start();
if(!empty($_SESSION['username'])){
    $displayName= $_SESSION['username'];
}
else{
    $displayName= 'Welcome';
}
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>

    <!-- Basic Page Needs ================================================== 
================================================== -->

    <meta charset="utf-8">
    <title>Services</title>
    <meta name="description" content="Place to put your description text">
    <meta name="author" content="">
    <!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

    <!-- Mobile Specific Metas ================================================== 
================================================== -->

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">

    <!-- CSS ==================================================
================================================== -->

    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/skeleton.css">
    <link rel="stylesheet" href="css/screen.css">
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />

    <!-- Favicons ==================================================
================================================== -->

    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">

    <!-- Google Fonts ==================================================
================================================== -->
    <link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
</head>

<body>

    <!--Content Part ==================================================
================================================== -->
    <div id="header">
        <div class="container">
            <!-- Header | Logo, Menu
		================================================== -->
            <div class="logo"><a href="index.php"><img src="images/work.png" alt="" height="90px" width="150px" /></a></div>
            <div class="mainmenu">
                <div id="mainmenu">
                    <ul class="sf-menu">
                        <li><a href="index.php" id="visited">Home</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="features.php">Features</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="signup.php">Become a Professional</a></li>
                        <li><a href="login.php">Login / Signup</a></li>
                        <li><a href="logout.php">Hello <?php echo $displayName; ?></a></li>
                    </ul>
                </div>
                <!-- mainmenu ends here -->

                <!-- Responsive Menu -->
                <form id="responsive-menu" action="#" method="post">
                    <select>
                        <option value="">Navigation</option>
                        <option value="index.php">Home</option>
                        <option value="services.php">Services</option>
                        <option value="features.php">Features</option>
                        <option value="contact.php">Contact</option>
                        <option value="signup.php">Become a Professional</option>
                        <option value="login.php">Login / Signup</option>
                    </select>
                </form>
            </div>
            <!-- mainmenu ends here -->
        </div>
        <!-- container ends here -->
    </div>
    <!-- header ends here -->
    <!--Breadcrumbs ==================================================
================================================== -->
    <div class="breadcrumbs">
        <div class="container">
            <header>

                <h3>Appliances & Electronics Repair</h3>
            </header>
        </div>
        <!-- container ends here -->
        <hr class="separator1">
    </div>
    <!-- breadcrumbs ends here -->
    <!-- Portfolio ==================================================
================================================== -->
    <div class="container portfolio">
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/electronic/tv.png" alt="tv" />
                <div class="mask">
                    <h2><a href="workers.php">TV repair</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/electronic/AC-Repair.png" alt="ac" />
                <div class="mask">
                    <h2><a href="#">AC reapir</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third lastcolumn shadow">
            <div class="view view-first"> <img src="images/electronic/electronic-repair.jpg" alt="electronic" />
                <div class="mask">
                    <h2><a href="#">Fridge repair</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>

        &nbsp;
        <div class="break">
            <div class="breadcrumbs">
                <div class="container">
                    <header>
                        <h3>Womens Salon</h3>
                    </header>
                </div>


                <!-- container ends here -->
                <hr class="separator1">
            </div>
        </div>





        <!--end one_third-->
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/womensalon/beauty1.jpg" alt="womensalon" />
                <div class="mask">
                    <h2><a href="#">Hair Dry</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/womensalon/womens-hair-rc.jpg" alt="womensalon" />
                <div class="mask">
                    <h2><a href="#">Hair styling</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third lastcolumn shadow">
            <div class="view view-first"> <img src="images/womensalon/highlighting.jpg" alt="highlighting" />
                <div class="mask">
                    <h2><a href="#">High lighting</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        &nbsp;
        <div class="break">
            <div class="breadcrumbs">
                <div class="container">
                    <header>
                        <h3>Mens Grooming</h3>
                    </header>
                </div>


                <!-- container ends here -->
                <hr class="separator1">
            </div>
        </div>





        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/mensgroom/mensgoom3.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Hair waxing</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/mensgroom/mensgroom4.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Beard shaping</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third lastcolumn shadow">
            <div class="view view-first"> <img src="images/mensgroom/mensgroom2.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Face cleanup</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        &nbsp;
        <div class="break">
            <div class="breadcrumbs">
                <div class="container">
                    <header>
                        <h3>Cleaning</h3>
                    </header>
                </div>


                <!-- container ends here -->
                <hr class="separator1">
            </div>
        </div>



        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/cleaning/cleaning1.jpeg" alt="" />
                <div class="mask">
                    <h2><a href="#">Mat cleaning</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/cleaning/cleaning2.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Full house clean</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third lastcolumn shadow">
            <div class="view view-first"> <img src="images/cleaning/cleaning3.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Pest control</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->

        &nbsp;
        <div class="break">
            <div class="breadcrumbs">
                <div class="container">
                    <header>
                        <h3 id="photo">Photography</h3>
                    </header>
                </div>


                <!-- container ends here -->
                <hr class="separator1">
            </div>
        </div>



        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/photography/photoshoot.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Photoshoot</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/photography/wedding.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Wedding shoot</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third lastcolumn shadow">
            <div class="view view-first"> <img src="images/photography/event.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Event photography</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>


        &nbsp;
        <div class="break">
            <div class="breadcrumbs">
                <div class="container">
                    <header>
                        <h3>Decoration</h3>
                    </header>
                </div>


                <!-- container ends here -->
                <hr class="separator1">
            </div>
        </div>



        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/decoration/decoration1.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">christmas</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third shadow">
            <div class="view view-first"> <img src="images/decoration/decoration2.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">Event decoration</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        <!--end one_third-->
        <div class="one_third lastcolumn shadow">
            <div class="view view-first"> <img src="images/decoration/decoration3.jpg" alt="" />
                <div class="mask">
                    <h2><a href="#">house decoration</a></h2>
                </div>
                <!-- mask ends here -->
            </div>
            <!-- view ends here -->
        </div>
        
         <table align="center" border="1px" style="width:600px; line-height:40px;">
        <tr>
            <th colspan="4"><h2>Available Workers</h2></th>
        </tr>
        
<?php 
$connection = mysql_connect('localhost', 'root', ''); //The Blank string is the password
mysql_select_db('workforce');

$query = "SELECT * FROM workerprofile"; //You don't need a ; like you do in SQL
$result = mysql_query($query);



while($row = mysql_fetch_array($result)){   //Creates a loop to loop through results
 ?>        <t>
            <th> Name </th>
            <th> Email </th>
            <th> Expertise </th>
            <th> Contact Number </th>
        </t>
            <tr>
            
                <td><?php echo $row['firstname']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['expertise']; ?></td>
                <td><?php echo $row['phone_number']; ?></td>
            </tr>
    <?php     
        }   
mysql_close(); //Make sure to close out the database connection
        ?>
        </table>
    </div>
    <!-- container ends here -->
    <!-- Socialize ==================================================
================================================== -->
    <hr class="separator2">
    <div class="socialsblock">
        <div class="container socialize">
            <h3>Socialize with us!</h3>
            <section class="socials">
                <ul class="socials">
                    <li><a href="#"><img src="images/socials/twitter.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/facebook.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/dribbble.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/google+.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/linkedin.png" alt="" /></a></li>
                    <li><a href="#"><img src="images/socials/youtube.png" alt="" /></a></li>
                </ul>
            </section>
        </div>
        <!-- container ends here -->
    </div>
    <!-- socialsblock ends here -->
    <!-- Footer ==================================================
================================================== -->
    <div class="footer">
        <div class="container">
            <div class="one_fourth">
                <h3>Contact Informations</h3>
                <p><span class="orange"><strong>Address:</strong></span> <br>
                    425 Wilson Avenue, Kitchener, ON, Canada, N2C 2R8</p>
                <p><span class="orange"><strong>Phone:</strong></span> <br>
                    +1(226)9724868<br>
                </p>
                <p><span class="orange"><strong>Email:</strong></span> <br>
                    info@workforcealliance.com<br>
                </p>
            </div>
            <!-- four columns ends here -->
            <div class="one_fourth">
                <h3>Our Services</h3>
                <ul>
                    <li><a href="#" title="">Electrnoic Repair</a></li>
                    <li><a href="#" class="">Plumbing</a></li>
                    <li><a href="#" class="">Hair Artists</a></li>
                    <li><a href="#" class="">Photography</a></li>
                    <li><a href="#" class="">Decoration</a></li>
                </ul>
            </div>
            <!-- four columns ends here -->
            <div class="one_fourth">
                <h3>Archive</h3>
                <ul>
                    <li><a href="#" class=""> August 2019</a></li>
                    <li><a href="#" class="">July 2019</a></li>
                    <li><a href="#" class="">Juny 2019</a></li>
                    <li><a href="#" class=""> May 2019</a></li>
                    <li><a href="#" class="">April 2019</a></li>
                </ul>
            </div>
            <!-- four columns ends here -->
            <div class="one_fourth lastcolumn">
                <h3>About</h3>
                <p>Workforce Alliance is a company that helps you to find what you need!</p>
            </div>
            <!-- four columns ends here -->
        </div>
        <!-- container ends here -->
    </div>
    <!-- footer ends here -->
    <!-- Copyright ==================================================
================================================== -->
    <div id="copyright">
        <div class="container">
            <p class="copyright">&copy; Copyright 2019. &quot;WorkForce Alliance&quot; All rights reserved.</p>
        </div>
        <!-- container ends here -->
    </div>
    <!-- copyright ends here -->
    <!-- End Document
================================================== -->
    <!-- Scripts ==================================================
================================================== -->
    <script src="js/jquery-1.8.0.min.js" type="text/javascript"></script>
    <!-- Main js files -->
    <script src="js/screen.js" type="text/javascript"></script>
    <!-- Tabs -->
    <script src="js/tabs.js" type="text/javascript"></script>
    <!-- Include prettyPhoto -->
    <script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
    <!-- Include Superfish -->
    <script src="js/superfish.js" type="text/javascript"></script>
    <script src="js/hoverIntent.js" type="text/javascript"></script>
    <!-- Flexslider -->
    <script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
    <!-- Modernizr -->
    <script type="text/javascript" src="js/modernizr.custom.29473.js"></script>
</body>

</html>
